<?php

  class Utils {
    private $configurationFile;

    function __construct() {
      $this->configurationFile = $_SERVER['DOCUMENT_ROOT'].'/conf.json';
    }

    /**
     * Get configuration
     *
     * @return $parsedConfig
     */
    public function getConfig () {
      $rawConfigString = file_get_contents($this->configurationFile);
      $parsedConfig = json_decode($rawConfigString);
      return $parsedConfig;
    }

    /**
     * Create Database connection then return the instance
     *
     * @return $databaseConnection
     */
    public function getDatabaseConnection () {
      # fetch config
      $connectionParams = $this->getConfig()->database;

      # create the connection
      $connection = mysqli_connect(
        $connectionParams->host,
        $connectionParams->user,
        $connectionParams->password,
        $connectionParams->dbname,
        $connectionParams->port
      );

      #check connection
      if (mysqli_connect_error()) {
        die();
      }
      return $connection;
    }
  }
?>

