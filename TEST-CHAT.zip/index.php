<!DOCTYPE html>
<html>
  <head>
    <title>Chat</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/vendor/tachyons.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="js/vendor/angular.js"></script>
    <script src="js/vendor/moment.js"></script>
  </head>
  <body>
    <div class="absolute bg-near-white top-0 left-0 w-100 h-100 sans-serif" ng-app="chat-app" ng-controller="chat-app-controller">
      <div class="w-100 h-100 ph4 pv4 flex items-center content-center tc">
        <?php include 'components/messaging.html'; ?>
        <?php include 'components/signin.html'; ?>
      </div>
    </div>
    <script src="js/app.js"></script>
  </body>
</html>