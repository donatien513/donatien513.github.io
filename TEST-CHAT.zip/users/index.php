<?php

  session_start();

  include_once $_SERVER['DOCUMENT_ROOT'].'/utils.php';

  # Class that handle CRUDs of the chat
  class Users {
    private $databaseConnection;

    function __construct() {
      $utils = new Utils();
      $this->databaseConnection = $utils->getDatabaseConnection();
    }

    /**
     * Fetch users from database
     *
     * @return $result
     */
    public function get ($option) {
      $tableName = '`users`';
      $fieldsToReturn = [
        '`id`',
        '`name`'
      ];

      $query = 'SELECT '.join(', ', $fieldsToReturn).' FROM '.$tableName;
      if (isset($option->name) && isset($option->password)) {
        $query = $query.' WHERE ';
        $query = $query.' `name`='.'\''.$option->name.'\'';
        $query = $query.' AND ';
        $query = $query.' `password`='.'\''.$option->password.'\'';
      } else if (isset($option->id)) {
        $query = $query.' WHERE ';
        $query = $query.' `id`='.$option->id;
      }

      $result = mysqli_query($this->databaseConnection, $query);

      $fetchedFields = mysqli_fetch_all($result, MYSQLI_ASSOC);

      # Close the connection
      mysqli_free_result($result);
      mysqli_close($this->databaseConnection);

      switch (count($fetchedFields)) {
        case 0:
          return;
          break;

        case 1:
          $field = $fetchedFields[0];

          # Save the session (sign-in)
          $_SESSION['id'] = $field['id'];
          return $field;
          break;
        
        default:
          return $fetchedFields;
          break;
      }
    }
  }

  switch ($_SERVER['REQUEST_METHOD']) {
    # If request wants to read messages
    case 'GET':
      $users_handler = new Users();

      $option = new stdClass;

      if (isset($_GET['id'])) { $option->id = $_GET['id']; };
      if (isset($_GET['name'])) { $option->name = $_GET['name']; };
      if (isset($_GET['password'])) { $option->password = $_GET['password']; };

      $result = $users_handler->get($option);
      if ($result === null) {
        http_response_code(404);
        exit();
      }
      echo(json_encode($result));
      break;

    default:
      # Close the connection created in constructor
      # if the provided requested method is not supported
      $this->databaseConnection->close();
  }
?>