(() => {
  const app = angular.module('chat-app', []);
  app.controller('chat-app-controller', (
    $scope,
    $http,
    $interval
  ) => {

    $scope.data = {
      users: [],
      messages: [],
      connectedUser: null,
      oneTalkingWithMe: null,
      nextMessage: '',
      login: {
        name: '',
        password: ''
      }
    }

    /**
     * Sign-in flow
     *
     */
    $scope.signIn = async () => {
      try {
        if (!$scope.data.login.name && !$scope.data.login.password) return;
        const response = await $http({
          url: '/users/index.php',
          method: 'GET',
          params: {
            name: $scope.data.login.name,
            password: $scope.data.login.password,
          }
        });
        $scope.data.connectedUser = response.data.id;

        await Promise.all([
	      $scope.fetchMessage(),
	      $scope.getUsers()
        ]);
      } catch (err) {
        if (err.status === 404) {
          alert('L’authentification a échouée. Utilisateur non trouvé.');
        };
      };
    }

    /**
     * Decide message placement
     *
     */
    $scope.decideMessagePlacement = (message) => {
    	if (message.from == $scope.data.connectedUser) {
    		return 'fl tl';
    	} else {
    		return 'fr tr';
    	};
    }

    /**
     * Get a single user
     *
     */
    $scope.getUser = async (userID) => {
      try {
        const response = await $http({
          url: '/users/index.php',
          method: 'GET',
          params: {
            id: userID,
          }
        });
      } catch (err) {

      };
    }

    /**
     * Get all users
     *
     */
    $scope.getUsers = async () => {
      try {
        const response = await $http({
          url: '/users/index.php',
          method: 'GET'
        });
        $scope.data.users = response.data;
      } catch (err) {

      };
    }

    /**
     * Fetch messages
     *
     */
    $scope.fetchMessage = async () => {
      try {
        const response = await $http({
          url: '/messages/index.php',
          method: 'GET'
        });
        $scope.data.messages = response.data || $scope.data.messages;
      } catch (err) {

      };
    }

    /**
     * Send a single message
     *
     */
    $scope.sendMessage = async () => {
      try {
        await $http({
          url: '/messages/index.php',
          method: 'POST',
          data: {
            text: $scope.data.nextMessage,
            to: $scope.data.oneTalkingWithMe
          }
        });

        await $scope.data.fetchMessage();

        // remove the previously saved message
        $scope.data.nextMessage = '';
      } catch (err) {

      };
    }

    moment.locale('fr');
    $scope.moment = moment;


    const intervalUpdateInSecond = 3;

    /**
     * fetch messages each <intervalUpdateInSecond> seconds
     *
     */
    $interval(() => {
      if (!$scope.data.connectedUser) return;
      $scope.fetchMessage();
    }, intervalUpdateInSecond * 1000);
  });
})();