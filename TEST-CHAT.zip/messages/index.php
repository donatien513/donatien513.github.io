<?php

  session_start();

  include_once $_SERVER['DOCUMENT_ROOT'].'/utils.php';

  # Class that handle CRUDs of the chat
  class Messages {
    private $databaseConnection;

    function __construct() {
      $utils = new Utils();
      $this->databaseConnection = $utils->getDatabaseConnection();
    }

    /**
     * Commit write to database
     *
     * @param $from
     * @param $to
     * @param $message
     */
    public function push ($from, $to, $text) {
      $tableName = 'messages';
      $fieldsToFill = [
        '`from`='.$from,
        '`to`='.$to,
        '`text`='.'\''.$text.'\''
      ];

      if (isset($from) && isset($to) && isset($text)) {
        $queryFields = join(', ', $fieldsToFill);
        $query = 'INSERT INTO `'.$tableName.'` SET '.$queryFields.';';
        mysqli_query($this->databaseConnection, $query);

        # simple response with http code
        http_response_code(201);
      }

      # Close the connection
      mysqli_close($this->databaseConnection);
    }

    /**
     * Fetch messages from database
     *
     * @return $result
     */
    public function get () {
      $tableName = '`messages`';

      $query = 'SELECT * FROM '.$tableName;
      $result = mysqli_query($this->databaseConnection, $query);

      $fetchedFields = mysqli_fetch_all($result , MYSQLI_ASSOC);

      # Close the connection
      mysqli_free_result($result);
      mysqli_close($this->databaseConnection);
      return $fetchedFields;
    }
  }

  switch ($_SERVER['REQUEST_METHOD']) {
    # If request wants to read messsages
    case 'GET':
      $messages_handler = new Messages();
      echo(json_encode($messages_handler->get()));
      break;

    # If request wants to write messsages
    case 'POST':
      $parsedJsonPayload = json_decode(file_get_contents('php://input'));

      if (isset($parsedJsonPayload->text) && isset($parsedJsonPayload->to)) {
        $from =  $_SESSION['id'];
        $to = $parsedJsonPayload->to;
        $text = $parsedJsonPayload->text;

        $messages_handler = new Messages();
        $messages_handler->push($from, $to, $text);
      } else {
        # simple response with http code
        http_response_code(400);
      }
      break;

    default:
      # Close the connection created in constructor
      # if the provided requested method is not supported
      $this->databaseConnection->close();
  }
?>